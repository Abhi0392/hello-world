﻿using EmployeeDetails.Models;
using EmployeeDetails.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeDetails.EmpDAL
{
    public interface IEmployeeService
    {
        //To get All Employees
        List<EmployeeDet> GetAllEmployees();

        //To get Employees based on the search item
        List<EmployeeDet> GetEmployeeByName(string name);

        //To create new Employee record in DB
        EmpResponse SaveEmployee(EmployeeDet employeeDet);
    }
}
