﻿using EmployeeDetails.EmpDAL;
using EmployeeDetails.Models;
using EmployeeDetails.ViewModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeDetails.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        IEmployeeService _employeeServie;
        public EmployeeController(IEmployeeService service)
        {
            _employeeServie = service;
        }
        //<summary>
        //Get All Employee Details
        //</summary>
        [HttpGet, Route("[action]")]
        public IActionResult GetAllEmployees()
        {
            var response = new EmpResponse();
            try
            {
                var empresponse = _employeeServie.GetAllEmployees();
                if(empresponse == null)
                {
                    response.Message = "No record found";
                }
                return new  JsonResult(empresponse);
                
            }
            catch(Exception ex)
            {
                throw;
            }
        }
        //<summary>
        //Get All Employee Details By name
        //</summary>
        //<param name ="name"></param>
        [HttpGet, Route("[action]/{name}")]
        public IActionResult GetEmployeeByName(string name)
        {
            var response = new EmpResponse();
            var getEmpResponse = new List<EmployeeDet>() ;
            try
            {
                getEmpResponse = _employeeServie.GetEmployeeByName(name);
                if (getEmpResponse == null)
                {
                    getEmpResponse = _employeeServie.GetAllEmployees();
                    return new JsonResult(getEmpResponse);
                }
                else
                {
                    return new JsonResult(getEmpResponse);
                }
              

            }
            catch (Exception ex)
            {
                throw;
            }
        }
        /// <summary>
        /// save employee
        /// </summary>
        /// <param name="employeeModel"></param>
        /// <returns></returns>

        [HttpPost, Route("[action]")]
        public IActionResult SaveEmployees(EmployeeDet employeeModel)
        {
            try
            {
                var model = _employeeServie.SaveEmployee(employeeModel);
                return Ok(model);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
    }
}
