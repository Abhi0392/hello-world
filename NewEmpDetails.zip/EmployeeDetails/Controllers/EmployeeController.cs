﻿using EmployeeDetails.Authentication;
using EmployeeDetails.EmpDAL;
using EmployeeDetails.Models;
using EmployeeDetails.ViewModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDetails.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        IEmployeeService _employeeServie;
        private readonly ILogger<EmployeeController> _logger;

        public EmployeeController(IEmployeeService service, ILogger<EmployeeController> logger)
        {
            _employeeServie = service;
            _logger = logger;
        }
        //<summary>
        //Get All Employee Details
        //</summary>
        //[Authorize]
        [HttpGet, Route("[action]")]
        public IActionResult GetAllEmployees()
        {
            var response = new EmpResponse();

            try
            {
               
                Stopwatch watch = new Stopwatch();
                watch.Start();
                var empresponse = _employeeServie.GetAllEmployees();
                watch.Stop();

                if (empresponse == null)
                {
                    response.Message = "No record found";
                }
                _logger.LogInformation("GetAllEmployees response time is" + watch.ElapsedMilliseconds +"ms" );
                return new  JsonResult(empresponse);
                
            }
            catch(Exception ex)
            {
                throw;
            }
        }
        //<summary>
        //Get All Employee Details By name
        //</summary>
        //<param name ="name"></param>
        //[Authorize]
        [HttpGet, Route("[action]/{name}")]
        public IActionResult GetEmployeeByName(string name)
        {
            var response = new EmpResponse();
            var getEmpResponse = new List<EmployeeDet>() ;
            try
            {
                Stopwatch watch = new Stopwatch();
                watch.Start();
                getEmpResponse = _employeeServie.GetEmployeeByName(name);
                watch.Stop();
                if (getEmpResponse == null)
                {
                    getEmpResponse = _employeeServie.GetAllEmployees();

                    _logger.LogInformation("GetAllEmployees by name response time is:" + watch.ElapsedMilliseconds + "ms");
                    return new JsonResult(getEmpResponse);
                }
                else
                {
                    _logger.LogInformation("request data is" +name +"response time is:" + watch.ElapsedMilliseconds + "ms");
                    return new JsonResult(getEmpResponse);
                }
                

            }
            catch (Exception ex)
            {
                throw;
            }
        }
        /// <summary>
        /// save employee
        /// </summary>
        /// <param name="employeeModel"></param>
        /// <returns></returns>
        //[Authorize]
        [HttpPost, Route("[action]")]
        public IActionResult SaveEmployees(EmployeeDet employeeModel)
        {
            try
            {
                Stopwatch watch = new Stopwatch();
                watch.Start();
                var model = _employeeServie.SaveEmployee(employeeModel);
                watch.Stop();
                _logger.LogInformation("request data is " + employeeModel +"respnse time is:"+ watch.ElapsedMilliseconds + "ms");
                return Ok(model);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
     }
}

