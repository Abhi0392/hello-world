﻿using EmployeeDetails.Models;
using EmployeeDetails.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeDetails.EmpDAL
{
    public class EmpDataAccess : IEmployeeService
    {
        private EmployeeContext _empContext;
        public EmpDataAccess(EmployeeContext employeeContext)
        {
            _empContext = employeeContext;
        }

        public List<EmployeeDet> GetAllEmployees()
        {
            List<EmployeeDet> employees;
            try
            {
                employees = _empContext.Set<EmployeeDet>().ToList();
            }
            catch(Exception)
            {
                throw;
            }
            return employees;
        }

        public List<EmployeeDet> GetEmployeeByName(string name)
        {
            var employees = new List<EmployeeDet>();
            try
            {
              var  employee = _empContext.Set<EmployeeDet>().ToList();
                if (employee != null)
                {
                    employees = employee.Where(x => x.FirstName.Equals(name, StringComparison.OrdinalIgnoreCase) || x.LastName.Equals(name, StringComparison.OrdinalIgnoreCase)).Select(y => new EmployeeDet()
                    {
                        EmployeeId = y.EmployeeId,
                        FirstName=y.FirstName,
                        LastName=y.LastName,
                        Role=y.Role,
                        Department =y.Department,
                        CreatedAt =y.CreatedAt
                    }).ToList();
                    


                }
            }
            catch(Exception)
            {
                throw;
            }
            return employees;
        }

        public EmpResponse SaveEmployee(EmployeeDet employeeDet)
        {
            EmpResponse response = new EmpResponse();
            try
            {
                _empContext.Add<EmployeeDet>(employeeDet);
                response.Success = true;
                response.Message = "Employee Inserted";
                _empContext.SaveChanges();
                response.Success = true;
            }
            
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = "Insertion Failed due to" + ex.Message;
            }
            return response;
        }
    }
}
